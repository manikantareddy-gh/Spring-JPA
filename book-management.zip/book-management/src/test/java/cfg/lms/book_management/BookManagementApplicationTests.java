package cfg.lms.book_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
