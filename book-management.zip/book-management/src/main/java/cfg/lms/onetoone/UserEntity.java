package cfg.lms.onetoone;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(schema = "hotel", name = "huser")
public class UserEntity {
	@Id
	private int userId;
	@Column
	private String name;
	@ManyToMany
	@JoinTable(schema = "hotel", name = "booking", joinColumns = @JoinColumn(name = "userId"), inverseJoinColumns = @JoinColumn(name = "roomNo"))
	private List<RoomEntity> rooms;

}
