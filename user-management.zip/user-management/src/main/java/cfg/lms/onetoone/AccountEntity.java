package cfg.lms.onetoone;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

@Entity
@Data
@Table(schema = "library", name = "account")
public class AccountEntity {

    @Id
    private int aid;

    @Column(name = "acc_type")
    private String type;

    @ManyToOne
    @JoinColumn(name = "cid", referencedColumnName = "cid")
    @ToString.Exclude
    private CustomerEntity customer;
}
