package cfg.lms.onetoone;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(schema = "hotel", name = "room")
public class RoomEntity {
	@Id
	private String roomNo;
	@Column
	private String type;
	@ManyToMany(mappedBy="rooms")
	private List<UserEntity> users;

}
