package cfg.lms.onetoone;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InfoRespository extends JpaRepository<InfoEntity, Integer>{

}
