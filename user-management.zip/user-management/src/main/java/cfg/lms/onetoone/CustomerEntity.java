package cfg.lms.onetoone;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;
@Entity
@Data
@Table(schema="library",name="customer")
public class CustomerEntity {
	@Id
	private int cid;
    @Column(name = "cName")
	private String cname;
	@OneToOne(mappedBy = "customer")
	private InfoEntity info;
	 @OneToMany(mappedBy = "customer",fetch = FetchType.EAGER)
	private List<AccountEntity> accounts;
}
