package cfg.lms.bms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = { "cfg.lms" })
@EntityScan("cfg.lms")
@EnableJpaRepositories("cfg.lms")
public class BookManagementApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(BookManagementApplication.class, args);
//		BankRepository bankrepo = context.getBean(BankRepository.class);
//		List<BankEntity> bankEntity = bankrepo.findAll();
//		System.out.println("--***bank and branch details***--");
//		for (BankEntity bank : bankEntity) {
//			System.out.println(bank.getBname() + "---->" + bank.getBranch().getLocation());
//		}
		
//		BranchRepository branchrepo = context.getBean(BranchRepository.class);
//		Optional<BranchEntity> branch = branchrepo.findById(1);
//		if(branch.isPresent()) {
//			System.out.println("*****------------------*****");
//			for(CustomerEntity customer:branch.get().getCustomers()) {
//				System.out.println(customer.getCname());
//			}
//			System.out.println("*****------------------*****");
//		}
	}

}
