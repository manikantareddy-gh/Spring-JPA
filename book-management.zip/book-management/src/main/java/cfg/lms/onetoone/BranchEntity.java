package cfg.lms.onetoone;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(schema = "sbi", name = "branch")
public class BranchEntity {
	@Id
	private int branchId;

	@Column
	private String location;

	@OneToOne(mappedBy = "branch")
	private BankEntity bank;

	@OneToMany(mappedBy = "branch", fetch = FetchType.EAGER)
	private List<CustomerEntity> customers;

}
