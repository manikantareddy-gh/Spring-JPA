package cfg.lms.onetoone;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

@Entity
@Data
@Table(schema = "library", name = "information")
public class InfoEntity {

    @Id
    private int infoid;

    @Column
    private String aadhaar;

    @Column
    private String pan;

    @OneToOne
    @JoinColumn(name = "cid", referencedColumnName = "cid")
    @ToString.Exclude
    private CustomerEntity customer;
}
