package cfg.lms.ums;

import java.util.Optional;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import cfg.lms.onetoone.AccountEntity;
import cfg.lms.onetoone.CustomerEntity;
import cfg.lms.onetoone.CustomerRespository;

@SpringBootApplication(scanBasePackages = { "cfg.lms" })
@EntityScan("cfg.lms")
@EnableJpaRepositories("cfg.lms")
public class UserManagementApplication {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("please enter your Account id:    ");
		int val = sc.nextInt();
		sc.close();
		ConfigurableApplicationContext context = SpringApplication.run(UserManagementApplication.class, args);
		CustomerRespository customerrepo = context.getBean(CustomerRespository.class);
		Optional<CustomerEntity> customer = customerrepo.findById(val);
		if (customer.isPresent()) {
			System.out.println();
			System.out.println("******** Account Details ********");
			System.out.println("-------------------------------------");
			System.out.println("Account holder:		" + customer.get().getCname());
			for (AccountEntity account : customer.get().getAccounts()) {
				System.out.println("Avilable accounts:		" + account.getType());
			}
			System.out.println("Aadhaar number:		" + customer.get().getInfo().getAadhaar());
			System.out.println("PAN card number:		" + customer.get().getInfo().getPan());
			System.out.println();
		}
	}
}
